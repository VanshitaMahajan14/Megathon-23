import React, { useState } from 'react';
import axios from 'axios';
import { Container, Paper, Typography, Button, Grid, TextField, Box } from '@mui/material';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import Navbar from './Navbar';
import './Patient.css';

const theme = createTheme({
    palette: {
        primary: {
            main: '#FFFFFF',
        },
        secondary: {
            main: '#FFA500',
        },
        background: {
            default: '#FFFFFF'
            , // change the background color to black
        },
    },
});

function Patient() {
    const [userInput, setUserInput] = useState('');
    const [result, setResult] = useState('');

    const handleUserInput = (event) => {
        setUserInput(event.target.value);
    };

    const fetchData = () => {
        axios.post('http://127.0.0.1:5000/patient', { user_input: userInput })
            .then(response => {
                setResult(response.data.result);
            })
            .catch(error => {
                console.error(error);
            });
    };

    return (
        <>
            <Navbar />
            <ThemeProvider theme={theme}>
                <Container style={{ marginTop: '150px' }}>
                    <Paper style={{ padding: '20px', background: theme.palette.background.default }}>
                        <Grid container spacing={2}>
                            <Grid item xs={12}>
                                <TextField
                                    label="Enter your input"
                                    variant="outlined"
                                    fullWidth
                                    value={userInput}
                                    onChange={handleUserInput}
                                    style={{ background: theme.palette.background.default, color: 'white' }}
                                />
                                <Button
                                    variant="contained"
                                    color="secondary"
                                    onClick={fetchData}
                                    style={{ marginTop: '10px' }}
                                >
                                    Submit
                                </Button>
                            </Grid>
                        </Grid>
                    </Paper>
                    <Box style={{ marginTop: '70px', padding: '10px', background: theme.palette.background.default, color: 'black' }}>
                        <Typography variant="h5" fontFamily={["Lora", "serif"].join(",")}>
                            Result: 
                        </Typography>
                    </Box>
                    <Box style={{ marginTop: '20px', padding: '10px', background: theme.palette.background.default, color: 'black' }}>
                        <Typography variant="h6" fontFamily={["Lora", "serif"].join(",")}>
                            {result}
                        </Typography>
                    </Box>
                </Container>
            </ThemeProvider>
        </>
    );
}

export default Patient;
