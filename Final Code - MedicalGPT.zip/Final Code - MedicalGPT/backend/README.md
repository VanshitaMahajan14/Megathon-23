# Medical-Chatbot-Llama2

Download the Llama 2 Model: [llama-2-7b-chat.ggmlv3.q4_0.bin](https://huggingface.co/TheBloke/Llama-2-7B-Chat-GGML/tree/main)

Place the Llama 2 model in models folder

To run the chatbot use this command
```
flask run
```
