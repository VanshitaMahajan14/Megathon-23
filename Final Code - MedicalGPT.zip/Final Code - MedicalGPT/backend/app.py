from flask import Flask, request, render_template, jsonify
from flask_cors import CORS
import openai
from sentence_transformers import SentenceTransformer

from langchain import PromptTemplate
from langchain.chains import RetrievalQA
from langchain.embeddings import HuggingFaceEmbeddings
from langchain.vectorstores import Pinecone
import pinecone
from langchain.document_loaders import PyPDFLoader, DirectoryLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.prompts import PromptTemplate
from langchain.llms import CTransformers
from langchain.chat_models import ChatOpenAI
from dotenv import load_dotenv
import os
import timeit
import sys
load_dotenv()
PINECONE_API_KEY=os.environ.get('PINECONE_API_KEY','0ae196c6-b132-483a-a8f3-cf20ee9585f0')
PINECONE_API_ENV=os.environ.get('PINECONE_API_ENV', 'gcp-starter')

#***Extract Data From the PDF File***
def load_pdf_file(data):
    loader= DirectoryLoader(data,
                            glob="*.pdf",
                            loader_cls=PyPDFLoader)

    documents=loader.load()

    return documents

extracted_data=load_pdf_file(data='data/')

# #print(data)


#***Split the Data into Text Chunks****
def text_split(extracted_data):
    text_splitter=RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=20)
    text_chunks=text_splitter.split_documents(extracted_data)
    return text_chunks

text_chunks=text_split(extracted_data)
print("Length of Text Chunks", len(text_chunks))

#***Download the Embeddings from Hugging Face***
def download_hugging_face_embeddings():
    embeddings=HuggingFaceEmbeddings(model_name='sentence-transformers/all-MiniLM-L6-v2')
    return embeddings

# start = timeit.default_timer()
embeddings = download_hugging_face_embeddings()


#Initializing the Pinecone
pinecone.init(api_key=PINECONE_API_KEY,
              environment=PINECONE_API_ENV)

index_name="medical"

#Creating Embeddings for Each of The Text Chunks
# docsearch=Pinecone.from_texts([t.page_content for t in text_chunks], embeddings, index_name=index_name)

#If we already have an index we can load it like this
docsearch=Pinecone.from_existing_index(index_name, embeddings)

prompt_template="""
Use the following pieces of information to answer the user's question.
If you don't know the answer, just say that you don't know, don't try to make up an answer.

Context: {context}
Question: {question}

Only return the helpful answer below and nothing else.
Helpful answer:
"""

PROMPT=PromptTemplate(template=prompt_template, input_variables=["context", "question"])

chain_type_kwargs={"prompt": PROMPT}

llm=CTransformers(model="/Users/ashnadua/Downloads/Medical-Chatbot-Llama2-main/models/llama-2-7b-chat.ggmlv3.q4_0.bin",
                  model_type="llama",
                  config={'max_new_tokens':1500,
                          'temperature':0.9})

print("here")

app = Flask(__name__)

# Allow requests only from 'http://localhost:3001'
CORS(app, resources={r"/patient": {"origins": "http://localhost:3001"}})

@app.route("/")
def index():
    return render_template("index.html")

index = pinecone.Index('medical')

def qa_op(user_input):
    model_name = "sentence-transformers/all-MiniLM-L6-v2"
    model = SentenceTransformer(model_name)

    print("hello")
    openai.api_key = "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"

    # Get the query embedding
    query_embedding = model.encode([user_input])[0].tolist()
    print("hello2")
    results = index.query(
        vector=[query_embedding],
        top_k=5,
        include_values=True,
        include_metadata=True
    )
    print("hello3")
    met_dat = []
    for i in results["matches"]:
        met_dat.append(i["metadata"]["text"])

    print(met_dat)

    context = ' '.join(met_dat)

    prompt = f"""Use the following pieces of information to answer the user's question.
    If you don't know the answer, just say that you don't know, don't try to make up an answer.

    Context: {context}
    Question: {user_input}

    Helpful answer: """

    response = openai.Completion.create(
        engine="text-davinci-003",
        prompt=prompt,
        max_tokens=150,
        temperature=0.3,
    )

    print(response)

    if 'choices' in response and len(response['choices']) > 0:
        result = response['choices'][0]['text'].strip()
        return result
    else:
        return "No result found"
    

    # docs = index.query(
    #     vector=query_embedding,
    #     top_k=3,
    #     include_values=True
    # )

    # print(docs)

#     # Assuming you have a RetrievalQA object configured here
#     qa = RetrievalQA.from_chain_type(llm=llm, chain_type="stuff", retriever=docsearch.as_retriever(search_kwargs={'k': 1}), return_source_documents=True, chain_type_kwargs=chain_type_kwargs)
#     print(user_input)
#     result = qa({"query": user_input})
    
#     # Assuming 'result' contains a 'result' key that needs to be returned
#     if "result" in result:
#         return result["result"]
#     else:
#         return "No result found"  # Handle cases where 'result' is not available

# def retrieve_relevant_documents(user_input):
#     # Your mechanism to create a query vector from the user input
#     query_vector = your_vector_creation_logic(user_input)

#     # Query Pinecone index
#     results = index.query(queries=[query_vector])

#     return results

@app.route("/patient", methods=["POST"])
def qa_patient():
    data = request.get_json()
    user_input = data.get("user_input") if data else None

    print("User Input:", user_input)  # For debugging

    if user_input is None:
        return jsonify({"error": "No user input provided"})

    try:
        # Process the user input here and return the result
        result = qa_op(user_input)
        return jsonify({"result": result})

    except Exception as e:
        print("Error in processing user input:", e)
        return jsonify({"error": "Error occurred while processing the user input"})

if __name__ == "__main__":
    # Run the Flask app if the script is executed directly
    app.run(debug=True) 